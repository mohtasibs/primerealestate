<div class="row align-items-center justify-content-between g-4">
			
    <div class="col-xl-5 col-lg-5 col-md-5">
        <div class="callsTitles">
            <h4 class="text-white mb-0 lh-base">Subscribe Our Newsletter!</h4>
            <p class="text-white opacity-75 m-0">Subscribe our marketing platforms for latest updates</p>
        </div>
    </div>
    
    <div class="col-xl-5 col-lg-6 col-md-6">
        <div class="subscribeForm">
            <div class="inputGroup">
                <input type="email" class="form-control" placeholder="Your Email Here...">
                <button class="btn btn-whites"><i class="fa-regular fa-paper-plane me-2"></i>Subscribe</button>
            </div>
        </div>
    </div>

</div>